Homework 3: Responsive Layout

Files:
- index.html: webpage structure and content
- style.css: styling, CSS Grid, and responsive media queries

To preview: open index.html in a web browser.
Responsive behavior: 3 columns on desktop, 2 columns at widths up to 768px, and 1 column at widths up to 480px.

Before submitting, confirm your instructor accepts a new portfolio page because the assignment description asks you to redesign your Homework 2 page.
